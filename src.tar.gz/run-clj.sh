#!/bin/bash
clojure -M ./solution.clj <in.txt

cd - >/dev/null
